package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InsufficientAmountException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException {		
		BankingServices services = new BankingServicesImpl();
		long accountNoTo,accountNoFrom,transferAmount;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1. create Account");
		System.out.println("2. get account details");
		System.out.println("3. get every account details");
		System.out.println("4.deposit amount");
		System.out.println("5.withdraw amount");
		System.out.println("6.transaction ");
		int n = sc.nextInt();
		switch(n) {
		case 1: 
			System.out.println("Enter the type of account you want to open: 'savings'/'current' ");
			String accountType=sc.next();
			System.out.println("Enter your current Balance");
			long initialBalance=sc.nextLong();
			try{
				Account account = services.openAccount(accountType,initialBalance);
				System.out.println(account);
				System.out.println("account created");
			}
			catch(InvalidAmountException e) {
				e.printStackTrace();
				//System.out.println("invalid amount , please keep 500 minimum \n"+e);
			}
			catch(InvalidAccountTypeException e) {
				e.printStackTrace();
				//System.out.println("invalid account type \n"+e);
			}
			break;	
		case 2:
			System.out.println("Enter account no.");
			long accountNumber=sc.nextLong();
			try {
				System.out.println(services.getAccountDetails(accountNumber));
			} 
			catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 3 : 
			System.out.println(services.getAllAccountDetails());
			break;	
		case 4:
			System.out.println("Enter 'accountNo' and 'amount to deposit' ");
			long accountNumber1=sc.nextLong();
			try {
				System.out.println(services.getAccountDetails(accountNumber1));
			} 
			catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			float amount1 = sc.nextFloat();
			BankingServicesImpl account1 = new BankingServicesImpl();
			account1.depositAmount(accountNumber1, amount1);
			break;	
		case 5:
			System.out.println("Enter 'accountNo', 'amount to withdraw' and 'pinNumber'");
			long accountNumber2=sc.nextLong();
			try {
				System.out.println(services.getAccountDetails(accountNumber2));
			} 
			catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			float amount2=sc.nextFloat();
			int pinNumber = sc.nextInt();
			BankingServicesImpl account2 = new BankingServicesImpl();
			try {
				account2.withdrawAmount(accountNumber2, amount2, pinNumber);}
			catch(InvalidPinNumberException e) {
				e.printStackTrace();
			}
			break;	
		case 6:
			System.out.println("enter accNo to transfer money to :");
			accountNoTo=sc.nextLong();
			System.out.println("enter amount to transfer");
			transferAmount=sc.nextLong();
			System.out.println("enter accNo from where the money will be transferred : ");
			accountNoFrom=sc.nextLong();
			System.out.println("enter pin no to complete the transaction");
			pinNumber=sc.nextInt();
			try {
				System.out.println("fund transfer : \n"+services.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber));
				System.out.println("transaction done to : \n"+services.getAccountDetails(accountNoTo)+"\n"+"from \n"+services.getAccountDetails(accountNoFrom));
			}
			catch(InsufficientAmountException|InvalidPinNumberException|BankingServicesDownException|AccountNotFoundException|AccountBlockedException e) {
				e.printStackTrace();
			}
			break;
		default: 
			System.out.println("enter correct choice");
		}

		System.out.println("1. continue");
		System.out.println("2. exit");
		int i=sc.nextInt();
		if(i==2) {
			System.exit(0);
		}
		main(null);
	}
}

