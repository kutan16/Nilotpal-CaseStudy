package com.cg.ticketing.exceptions;

public class TicketUnavailableException extends Exception {
	public TicketUnavailableException() {
		System.out.println("Ticket IS Unavailable");	}
}
